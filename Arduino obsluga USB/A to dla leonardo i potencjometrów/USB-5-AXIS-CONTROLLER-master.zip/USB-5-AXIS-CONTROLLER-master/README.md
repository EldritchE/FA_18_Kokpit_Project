# USB-5-AXIS-CONTROLLER
USB 5 AXIS CONTROLLER by AMSTUDIO 2018

Use with Arduino Leonardo or ProMicro.
Install Joystick library

Wiring + Setup https://youtu.be/iKIrbF6GnZ0


YT https://www.youtube.com/channel/UCQS1ZB3BVSrBo3tCs7PyfxQ


Copyright _ Non Commerical_ Not for Resale https://creativecommons.org/licenses/by-nc-nd/4.0/ 
